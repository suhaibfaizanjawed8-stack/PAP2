# Deploy the existing website on Vercel

This is a static website with 26 HTML pages. The existing `dist` directory contains the complete website source. Keep it in Git. No React, Next.js, compilation, package downloads or secret environment variables are required.

## Verify locally

Use Node.js 18 or newer:

```sh
node scripts/verify-site.mjs
node serve.mjs
```

Open http://127.0.0.1:4173/. The verification script only checks files; it does not rewrite, minify or redesign them.

## GitHub placement

Commit the contents of this project folder, including `dist`, `scripts`, `package.json`, `serve.mjs`, `vercel.json`, `.gitignore` and the documentation. Do not commit a ZIP in place of the source files.

If the destination repository already contains another project, preserve its files and place this project in a separate folder or review branch. Review and merge a pull request before changing a production branch that may trigger automatic deployments.

`.gitignore` excludes environment files, credentials, dependency folders, temporary archives and local hosting identities. The old `.openai/hosting.json` is not needed for Vercel and is excluded from Git and Vercel uploads. No secrets are required for this website.

## Import into Vercel

1. Sign in to Vercel, select **Add New → Project**, and import the GitHub repository.
2. Select the folder containing this file and `vercel.json` as the **Root Directory**. Use the repository root if the project is committed there.
3. Confirm the following settings, which are also supplied by `vercel.json`:

   | Setting | Value |
   |---|---|
   | Framework Preset | Other |
   | Install Command | Empty / skipped |
   | Build Command | `node scripts/verify-site.mjs` |
   | Output Directory | `dist` |
   | Environment variables | None required |

4. Deploy to a new Vercel project or review a branch preview first. Do not attach the existing business domain or replace an existing production project until the owner approves.
5. Check the homepage, `/products/`, a nested product page, `/blog/`, a nested article and `/contact/` at the Vercel URL.

Each page is a real directory with `index.html`. Do not add a catch-all rewrite to the homepage; it would break the multi-page website. `trailingSlash: true` preserves its existing slash-terminated URLs.

## Existing functionality and launch details

- All HTML, CSS, JavaScript, images and local fonts retain the existing design and behavior.
- Quote forms currently prepare email or download an enquiry; the direct-submission link opens the existing Prince Art Packages form. Vercel deployment does not turn those forms into an email backend.
- Google Maps and the existing secure enquiry form require internet access.
- Social image metadata still uses the prior configured Site origin. Before a public launch, update that metadata to the approved Vercel/custom domain; no visible design changes are required.
- No custom domain, DNS record, production deployment or existing live website is changed by preparing these files.

Official references:
- https://vercel.com/docs/project-configuration/vercel-json
- https://vercel.com/docs/git/vercel-for-github
